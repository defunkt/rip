module Choice
  module Version #:nodoc:
    MAJOR  = 0
    MINOR  = 1
    TINY   = 4
    STRING = [MAJOR, MINOR, TINY] * '.'
  end
end
